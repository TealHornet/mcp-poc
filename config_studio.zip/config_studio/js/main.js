$(document).ready(function() {
    // Dashboard: Save new project
    $('#saveProject').on('click', function() {
        const projectName = $('#projectName').val();
        const domain = $('#domain').val();
        const market = $('#market').val();

        if (projectName && domain && market) {
            const newRow = `
                <tr>
                    <td><a href="config.html">${projectName}</a></td>
                    <td>${domain}</td>
                    <td>${market}</td>
                    <td><button class="btn btn-danger btn-sm delete-project">Delete</button></td>
                </tr>
            `;
            $('table tbody').append(newRow);
            $('#createProjectModal').modal('hide');
            $('#createProjectForm')[0].reset();
        }
    });

    // Dashboard: Delete project
    $('table').on('click', '.delete-project', function() {
        $(this).closest('tr').remove();
    });

    // Config: Add item to allow list
    $('#add-allow').on('click', function() {
        const newItem = `
            <div class="input-group mb-2">
                <input type="text" class="form-control">
                <div class="input-group-append">
                    <button class="btn btn-outline-danger remove-item" type="button">Remove</button>
                </div>
            </div>
        `;
        $('#allow-list').append(newItem);
    });

    // Config: Add item to disallow list
    $('#add-disallow').on('click', function() {
        const newItem = `
            <div class="input-group mb-2">
                <input type="text" class="form-control">
                <div class="input-group-append">
                    <button class="btn btn-outline-danger remove-item" type="button">Remove</button>
                </div>
            </div>
        `;
        $('#disallow-list').append(newItem);
    });

    // Config: Remove item from allow/disallow list
    $('#allow-list, #disallow-list').on('click', '.remove-item', function() {
        $(this).closest('.input-group').remove();
    });

    // Config: Add document type configuration
    let docTypeCounter = 0;
    $('#add-doc-type').on('click', function() {
        docTypeCounter++;
        const newDocTypeForm = `
            <div class="card mt-3" id="doc-type-${docTypeCounter}">
                <div class="card-body">
                    <h5 class="card-title">New Document Type</h5>
                    <div class="form-group">
                        <label>Document Type Name</label>
                        <input type="text" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Document Identification</label>
                        <select class="form-control doc-identification-select">
                            <option value="regex">Regex</option>
                            <option value="rag">RAG</option>
                        </select>
                    </div>
                    <div class="identification-fields">
                        <div class="regex-fields">
                            <label>Regex Patterns</label>
                            <div class="regex-list">
                                <div class="input-group mb-2">
                                    <input type="text" class="form-control">
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-danger remove-regex" type="button">Remove</button>
                                    </div>
                                </div>
                            </div>
                            <button class="btn btn-outline-primary btn-sm add-regex" type="button">Add Regex</button>
                        </div>
                        <div class="rag-fields" style="display: none;">
                            <div class="form-group">
                                <label>Document Identification Prompts</label>
                                <textarea class="form-control" rows="3"></textarea>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <h6>Taxonomy Fields</h6>
                    <div class="taxonomy-fields-list">
                        <!-- Taxonomy fields will be added here -->
                    </div>
                    <button class="btn btn-secondary btn-sm add-taxonomy-field" type="button">Add Taxonomy Field</button>
                    <button class="btn btn-danger btn-sm float-right remove-doc-type" type="button">Remove Document Type</button>
                </div>
            </div>
        `;
        $('#doc-type-configs').append(newDocTypeForm);
    });

    // Config: Toggle between Regex and RAG fields
    $('#doc-type-configs').on('change', '.doc-identification-select', function() {
        const selectedValue = $(this).val();
        const parentCard = $(this).closest('.card-body');
        if (selectedValue === 'regex') {
            parentCard.find('.regex-fields').show();
            parentCard.find('.rag-fields').hide();
        } else {
            parentCard.find('.regex-fields').hide();
            parentCard.find('.rag-fields').show();
        }
    });

    // Config: Add/Remove Regex fields
    $('#doc-type-configs').on('click', '.add-regex', function() {
        const newRegexField = `
            <div class="input-group mb-2">
                <input type="text" class="form-control">
                <div class="input-group-append">
                    <button class="btn btn-outline-danger remove-regex" type="button">Remove</button>
                </div>
            </div>
        `;
        $(this).siblings('.regex-list').append(newRegexField);
    });
    $('#doc-type-configs').on('click', '.remove-regex', function() {
        $(this).closest('.input-group').remove();
    });

    // Config: Add Taxonomy Field
    $('#doc-type-configs').on('click', '.add-taxonomy-field', function() {
        const newTaxonomyField = `
            <div class="card mt-2">
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label>Field Type</label>
                            <select class="form-control">
                                <option>str</option>
                                <option>list</option>
                                <option>object</option>
                            </select>
                        </div>
                        <div class="form-group col-md-8">
                            <label>Field Name</label>
                            <input type="text" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Field Description</label>
                        <textarea class="form-control" rows="2"></textarea>
                    </div>
                    <button class="btn btn-outline-danger btn-sm remove-taxonomy-field" type="button">Remove Field</button>
                </div>
            </div>
        `;
        $(this).siblings('.taxonomy-fields-list').append(newTaxonomyField);
    });

    // Config: Remove Taxonomy Field
    $('#doc-type-configs').on('click', '.remove-taxonomy-field', function() {
        $(this).closest('.card').remove();
    });
    
    // Config: Remove Document Type
    $('#doc-type-configs').on('click', '.remove-doc-type', function() {
        $(this).closest('.card').remove();
    });
});
